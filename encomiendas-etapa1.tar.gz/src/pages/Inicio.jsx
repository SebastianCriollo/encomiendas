import { useAuth } from '../context/AuthContext'
import { Chip, Tarjeta } from '../components/ui'

// Etapa 1: pantalla de bienvenida. El dashboard real llega en la etapa 5.
export default function Inicio() {
  const { perfil, esAdmin } = useAuth()
  const nombre = perfil?.nombre?.split(' ')[0] || ''
  const hoy = new Date().toLocaleDateString('es-EC', { weekday: 'long', day: 'numeric', month: 'long' })

  return (
    <div className="space-y-4">
      <div className="px-1">
        <p className="text-sm capitalize text-piedra">{hoy}</p>
        <h1 className="titulo-pagina mt-1">Hola{nombre ? `, ${nombre}` : ''}</h1>
        <div className="mt-3">
          <Chip color={esAdmin ? 'pasto' : 'cielo'}>{esAdmin ? 'Administrador' : 'Socio'}</Chip>
        </div>
      </div>

      <Tarjeta>
        <p className="text-sm text-piedra">Ganancia del mes</p>
        <p className="cifra-grande mt-2 text-niebla">$—</p>
        <p className="mt-3 text-sm text-piedra">Aparecerá cuando registres tus primeras encomiendas.</p>
      </Tarjeta>

      <Tarjeta hundida>
        <p className="font-medium">Lo que viene</p>
        <ul className="mt-2 space-y-1.5 text-sm">
          <li>· Clientes y su saldo pendiente</li>
          <li>· Encomiendas, abonos y gastos</li>
          <li>· Ganancias y reparto entre socios</li>
          <li>· Recibos en PDF para WhatsApp</li>
        </ul>
      </Tarjeta>
    </div>
  )
}
