import { NavLink, Outlet, Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { Cargando } from './ui'

const iconos = {
  inicio: <path d="M4 11l8-6 8 6v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z" />,
  socios: <><circle cx="9" cy="8" r="3.2" /><path d="M3.5 19c.6-3 2.8-4.6 5.5-4.6s4.9 1.6 5.5 4.6" /><circle cx="17" cy="9" r="2.4" /><path d="M16 14.6c2.3.1 3.9 1.5 4.5 4.4" /></>,
  cuenta: <><circle cx="12" cy="8" r="3.5" /><path d="M5 20c.8-3.6 3.6-5.5 7-5.5s6.2 1.9 7 5.5" /></>,
}

function Icono({ nombre }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {iconos[nombre]}
    </svg>
  )
}

export default function Layout() {
  const { session, perfil, esAdmin, cargando } = useAuth()
  const location = useLocation()

  if (cargando) return <Cargando />
  if (!session) return <Navigate to="/entrar" replace state={{ desde: location.pathname }} />

  // Usuario con sesión pero sin perfil activo (desactivado por el admin)
  if (perfil && !perfil.activo) {
    return (
      <main className="mx-auto max-w-md px-4 pt-24 text-center">
        <h1 className="titulo-pagina mb-3">Cuenta desactivada</h1>
        <p className="text-piedra">Habla con el administrador del negocio para volver a tener acceso.</p>
      </main>
    )
  }

  const items = [
    { a: '/', etiqueta: 'Inicio', icono: 'inicio' },
    ...(esAdmin ? [{ a: '/socios', etiqueta: 'Socios', icono: 'socios' }] : []),
    { a: '/cuenta', etiqueta: 'Cuenta', icono: 'cuenta' },
  ]

  return (
    <div className="mx-auto min-h-dvh max-w-2xl px-4 pb-32 pt-4">
      {/* Barra superior en forma de píldora */}
      <header className="mb-6 flex items-center justify-between rounded-full bg-blanco py-1.5 pl-4 pr-1.5">
        <div className="flex items-center gap-2.5">
          <img src="/icono.svg" alt="" className="size-8" />
          <span className="text-[15px] font-medium">Encomiendas</span>
        </div>
        <NavLink
          to="/cuenta"
          aria-label="Mi cuenta"
          className="flex size-10 items-center justify-center rounded-full bg-pasto text-sm font-medium"
        >
          {(perfil?.nombre || '?').charAt(0).toUpperCase()}
        </NavLink>
      </header>

      <main>
        <Outlet />
      </main>

      {/* Navegación inferior: al alcance del pulgar */}
      <nav
        aria-label="Navegación principal"
        className="fixed inset-x-0 bottom-0 z-10 px-4 pb-[max(1rem,env(safe-area-inset-bottom))]"
      >
        <ul className="mx-auto flex max-w-md justify-around rounded-full bg-tinta p-1.5">
          {items.map((it) => (
            <li key={it.a} className="flex-1">
              <NavLink
                to={it.a}
                end={it.a === '/'}
                className={({ isActive }) =>
                  `flex min-h-13 flex-col items-center justify-center gap-0.5 rounded-full text-[11px] font-medium transition ${
                    isActive ? 'bg-pasto text-tinta' : 'text-blanco/80'
                  }`
                }
              >
                <Icono nombre={it.icono} />
                {it.etiqueta}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  )
}
