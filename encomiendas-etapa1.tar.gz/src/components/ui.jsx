// Componentes base reutilizables: un solo lugar para el estilo de botones, campos y tarjetas.

export function Tarjeta({ className = '', hundida = false, children, ...props }) {
  return (
    <div
      className={`${hundida ? 'bg-arena' : 'bg-blanco'} rounded-tarjeta p-5 ${className}`}
      {...props}
    >
      {children}
    </div>
  )
}

// variante: "principal" (tinta + punto verde) | "secundario" (blanco con borde) | "peligro"
export function Boton({ variante = 'principal', cargando = false, className = '', children, ...props }) {
  const base =
    'inline-flex min-h-12 items-center gap-3 rounded-full px-5 text-[15px] font-medium transition active:scale-[0.98] disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-tinta'
  const estilos = {
    principal: 'bg-tinta text-blanco pl-6 pr-2 justify-between',
    secundario: 'justify-center bg-blanco text-tinta border border-niebla hover:border-tinta',
    peligro: 'justify-center bg-blanco text-tinta border-[1.5px] border-coral',
  }
  return (
    <button className={`${base} ${estilos[variante]} ${className}`} disabled={cargando || props.disabled} {...props}>
      <span>{cargando ? 'Un momento…' : children}</span>
      {variante === 'principal' && (
        <span aria-hidden="true" className="flex size-8 items-center justify-center rounded-full bg-pasto text-tinta">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
        </span>
      )}
    </button>
  )
}

export function Campo({ etiqueta, ayuda, error, id, className = '', ...props }) {
  const campoId = id || props.name
  return (
    <label htmlFor={campoId} className={`block ${className}`}>
      <span className="mb-1.5 block text-sm font-medium">{etiqueta}</span>
      <input
        id={campoId}
        className={`h-13 w-full rounded-campo border bg-blanco px-4 text-base outline-none transition placeholder:text-piedra/70 focus:border-tinta ${error ? 'border-coral' : 'border-niebla'}`}
        aria-invalid={!!error}
        {...props}
      />
      {error ? (
        <span className="mt-1.5 block text-sm text-[#b8402f]">{error}</span>
      ) : ayuda ? (
        <span className="mt-1.5 block text-sm text-piedra">{ayuda}</span>
      ) : null}
    </label>
  )
}

export function Aviso({ tipo = 'error', children }) {
  if (!children) return null
  const estilos = {
    error: 'border-coral bg-coral-tinte',
    ok: 'border-pasto bg-pasto-tinte',
    info: 'border-cielo bg-cielo-tinte',
  }
  return (
    <div role={tipo === 'error' ? 'alert' : 'status'} className={`rounded-campo border-[1.5px] px-4 py-3 text-sm ${estilos[tipo]}`}>
      {children}
    </div>
  )
}

export function Chip({ color = 'arena', punto, children }) {
  const fondos = {
    arena: 'bg-arena', cielo: 'bg-cielo-tinte', sol: 'bg-sol-tinte', pasto: 'bg-pasto-tinte', coral: 'bg-coral-tinte',
  }
  const puntos = { arena: 'bg-piedra', cielo: 'bg-cielo', sol: 'bg-sol ring-1 ring-tinta', pasto: 'bg-pasto', coral: 'bg-coral' }
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium ${fondos[color]}`}>
      {punto !== false && <span className={`size-2 rounded-full ${puntos[color]}`} />}
      {children}
    </span>
  )
}

export function Cargando({ texto = 'Cargando…' }) {
  return (
    <div className="flex min-h-[40vh] items-center justify-center text-piedra" role="status">
      <span className="mr-3 size-5 animate-spin rounded-full border-2 border-niebla border-t-tinta" />
      {texto}
    </div>
  )
}
