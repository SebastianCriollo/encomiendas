import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import Layout from './components/Layout'
import Entrar from './pages/Entrar'
import Inicio from './pages/Inicio'
import Socios from './pages/Socios'
import Cuenta from './pages/Cuenta'

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/entrar" element={<Entrar />} />
          <Route element={<Layout />}>
            <Route path="/" element={<Inicio />} />
            <Route path="/socios" element={<Socios />} />
            <Route path="/cuenta" element={<Cuenta />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}
