# Encomiendas

App web para llevar el control del negocio de encomiendas EE.UU. → Ecuador.
React + Vite + Tailwind · Supabase (PostgreSQL + Auth) · Netlify.

## Estructura

```
encomiendas/
├─ supabase/
│  ├─ schema.sql                       ← tablas, seguridad (RLS), auditoría
│  └─ functions/gestionar-usuarios/    ← función para crear socios (usa la clave secreta en el servidor)
├─ src/
│  ├─ lib/supabase.js                  ← conexión (solo anon key)
│  ├─ context/AuthContext.jsx          ← sesión y perfil del usuario
│  ├─ components/                      ← Layout y componentes base (Boton, Campo, Tarjeta, Chip)
│  └─ pages/                           ← Entrar, Inicio, Socios, Cuenta
├─ .env.example                        ← plantilla de variables (el .env real NO se sube)
└─ netlify.toml                        ← configuración de despliegue
```

## Puesta en marcha (etapa 1)

1. **Node.js 22 LTS**: https://nodejs.org (comprueba con `node -v`).
2. **Proyecto Supabase**: https://supabase.com → New project (plan Free). Guarda la contraseña de la base.
3. **Base de datos**: Supabase → SQL Editor → New query → pega `supabase/schema.sql` → Run.
4. **Cerrar registro público**: Authentication → Sign In / Providers → desactiva *Allow new users to sign up*.
   Email queda activado; desactiva *Confirm email*.
5. **Tu usuario admin**: Authentication → Users → Add user → Create new user (tu correo + contraseña,
   marca *Auto Confirm User*). El primer usuario queda como **admin** automáticamente.
6. **Función de usuarios**: Edge Functions → Deploy a new function → Via Editor → nombre
   `gestionar-usuarios` → pega `supabase/functions/gestionar-usuarios/index.ts` → Deploy.
7. **Variables**: copia `.env.example` como `.env` y pon la Project URL y la anon/publishable key
   (Project Settings → API Keys). **Nunca** la service_role / secret key.
8. **Ejecutar**:
   ```
   npm install
   npm run dev
   ```
   Abre http://localhost:5173. Para probar desde el celular en la misma Wi-Fi: `npm run dev -- --host`.

## Roles

| | Admin | Socio |
|---|---|---|
| Ver todo el negocio | ✔ | ✔ |
| Crear / editar clientes, encomiendas, abonos, gastos | ✔ | ✔ |
| Borrar registros | ✔ | ✘ |
| Crear socios, quitar acceso, cambiar contraseñas | ✔ | ✘ |
| Definir porcentajes y registrar pagos a socios | ✔ | ✘ |
| Ver historial de cambios | ✔ | ✘ |

Estas reglas viven en la base de datos (RLS), así que se cumplen aunque alguien modifique la app.
